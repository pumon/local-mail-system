package mail;
import javax.swing.*;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.border.CompoundBorder;
public class Account extends Login  {
JFrame jfacc,jf;
private JTextField textField;
private JTextField textField_1;
JTextArea textArea;
private JTable table;
ResultSet rs,rs_1,rs_2,rs_3,rs_temp;
Connection conn;
final String url=new String("jdbc:oracle:thin:@DESKTOP-KH3F8LR:1521:orcl");
final String user=new String("system");
final String auth=new String("ullas");
PreparedStatement st,st1;

private JTable table_1;
DefaultTableModel model,model_1,model_2,model_3;
private JTable table_2;
private JTable table_3;
private JCheckBox check1;
DateTimeFormatter df = DateTimeFormatter.ofPattern("MM/dd/yyyy");
DateTimeFormatter tf = DateTimeFormatter.ofPattern("HH:mm:ss");
	@SuppressWarnings("serial")
	Account (final String ac,final String name)
	{
		jfacc=new JFrame("Welcome "+ac);
		jfacc.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	      jfacc.setBounds(0,0,screenSize.width, screenSize.height);
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("Tahoma", Font.PLAIN, 15));
		 tabbedPane.setLocation(290,85);
		tabbedPane.setSize(715,593);
		JPanel jp2=new JPanel();
		JPanel jp5=new JPanel();
		String [] header={"Sender","Subject","Message","Date","Time"};
       model = new DefaultTableModel(null,header)	   
       {
    	   public boolean isCellEditable(int row, int column)
    	   {
    		      return false;//This causes all cells to be not editable
    	   }
       }; 
        try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection(url,user,auth);
			st=conn.prepareStatement("Select sender_name,subject,message,re_date,time from "+ac+"_inbox order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=st.executeQuery();
			while(rs.next())
			{
				String sendname=rs.getString("sender_name");
				String sub=rs.getString("subject");
				String mess=rs.getString("message");
				String date=rs.getString("re_date");
				date=date.substring(0,10);
				String time=rs.getString("time");
				model.addRow(new Object[] {sendname,sub,mess,date,time});
			}
			model.fireTableDataChanged();
			conn.close();
			st.close();
			rs.close();
		}
        catch(Exception e)
        {
        	JOptionPane.showMessageDialog(null,""+e);
        }
		JPanel jp1=new JPanel();
		
		tabbedPane.add("Inbox", jp1);
		
		table = new JTable(model);
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		        table.setPreferredScrollableViewportSize(new Dimension(640,435));
		        table.setFillsViewportHeight(true);
		        JScrollPane js_4=new JScrollPane(table);
		        
		        js_4.setVisible(true);

		        JButton btnView = new JButton("View");
		        btnView.setFont(new Font("Tahoma", Font.BOLD, 13));
		        btnView.addActionListener(new ActionListener() {
		        	public void actionPerformed(ActionEvent arg0) {
		        		new Read(ac,"inbox",table.getSelectedRow());
		        		
		        	}
		        });
		        
		        JButton btnRefresh_1 = new JButton("Refresh");
		        btnRefresh_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		        btnRefresh_1.addActionListener(new ActionListener() {
		        	public void actionPerformed(ActionEvent e) {
		        		try
		        		{
		        			Class.forName("oracle.jdbc.driver.OracleDriver");
		        			conn=DriverManager.getConnection(url,user,auth);
		        			st=conn.prepareStatement("Select sender_name,subject,message,re_date,time from "+ac+"_inbox order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		        			rs=st.executeQuery();
		        			model.setRowCount(0);
		        			while(rs.next())
		        			{
		        				String sendname=rs.getString("sender_name");
		        				String sub=rs.getString("subject");
		        				String mess=rs.getString("message");
		        				String date=rs.getString("re_date");
		        				date=date.substring(0,10);
		        				String time=rs.getString("time");
		        				model.addRow(new Object[] {sendname,sub,mess,date,time});
		        			}
		        			rs.close();
		        			conn.close();
		        			st.close();
		        		}
		                catch(Exception e1)
		                {
		                	JOptionPane.showMessageDialog(null,""+e1);
		                }
		        		table = new JTable(model);
		                table.setPreferredScrollableViewportSize(new Dimension(640,435));
		                table.setFillsViewportHeight(true);
		                JScrollPane js=new JScrollPane(table);
		                js.setVisible(true);
		        		
		        	}
		        });
		        
		        JButton btnDelete = new JButton("Delete");
		        btnDelete.setFont(new Font("Tahoma", Font.BOLD, 13));
		        btnDelete.addActionListener(new ActionListener() {
		        	public void actionPerformed(ActionEvent arg0) {
		        		try{
		        			LocalDateTime obj=LocalDateTime.now();
		            		Class.forName("oracle.jdbc.driver.OracleDriver");
		        			conn=DriverManager.getConnection(url,user,auth);
		        			Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		        			rs=stm.executeQuery("Select sender_id,sender_name,receiver_name,subject,message,re_date,time,attach,attach_type from "+ac+"_inbox order by re_date desc");
		            		rs.absolute(table.getSelectedRow()+1);
		            		st1=conn.prepareStatement("insert into "+ac+"_trash values(?,?,?,?,?,to_date(?,'MM/DD/YYYY HH24:MI:SS'),?,?,?)");
		            		st1.setString(1,rs.getString("sender_id"));
		            		st1.setString(2,rs.getString("sender_name"));
		            		st1.setString(3,rs.getString("receiver_name"));
		            		st1.setString(4,rs.getString("subject"));
		            		st1.setString(5,rs.getString("message"));
		            		st1.setString(6,df.format(obj));
		            		st1.setString(7,tf.format(obj));
		            		st1.setBlob(8,rs.getBlob("attach"));
		            		st1.setString(9,rs.getString("attach_type"));
		            		st1.executeQuery();
		            		rs.absolute(table.getSelectedRow()+1);
		            		rs.deleteRow();
		            		conn.close();
		            		st.close();
		            		JOptionPane.showMessageDialog(null,"Delete Successful");
		            		st1.close();
		            		rs.close();
		            	}
		            	catch(Exception e)
		            	{
		            		JOptionPane.showMessageDialog(null,""+e);
		            	}	            	
		        	}
		        });
		        
		         GroupLayout gl_jp1 = new GroupLayout(jp1);
		         gl_jp1.setHorizontalGroup(
		         	gl_jp1.createParallelGroup(Alignment.LEADING)
		         		.addGroup(gl_jp1.createSequentialGroup()
		         			.addGroup(gl_jp1.createParallelGroup(Alignment.LEADING)
		         				.addGroup(gl_jp1.createSequentialGroup()
		         					.addGap(118)
		         					.addComponent(btnView, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
		         					.addGap(66)
		         					.addComponent(btnRefresh_1, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
		         					.addGap(70)
		         					.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE))
		         				.addGroup(gl_jp1.createSequentialGroup()
		         					.addContainerGap()
		         					.addComponent(js_4, GroupLayout.DEFAULT_SIZE, 690, Short.MAX_VALUE)))
		         			.addContainerGap())
		         );
		         gl_jp1.setVerticalGroup(
		         	gl_jp1.createParallelGroup(Alignment.LEADING)
		         		.addGroup(gl_jp1.createSequentialGroup()
		         			.addContainerGap()
		         			.addComponent(js_4, GroupLayout.PREFERRED_SIZE, 492, GroupLayout.PREFERRED_SIZE)
		         			.addPreferredGap(ComponentPlacement.UNRELATED)
		         			.addGroup(gl_jp1.createParallelGroup(Alignment.BASELINE)
		         				.addComponent(btnRefresh_1, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
		         				.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
		         				.addComponent(btnView, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
		         			.addContainerGap())
		         );
		         jp1.setLayout(gl_jp1);

		tabbedPane.add("Sent MAil", jp2);
		 model_1 = new DefaultTableModel(null,header)
		 {
	    	   public boolean isCellEditable(int row, int column)
	    	   {
	    		      return false;//This causes all cells to be not editable
	    	   }
	       };;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection(url,user,auth);		
			st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,time from "+ac+"_sent order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs_1=st.executeQuery();			
			while(rs_1.next())
			{
				String sendname=rs_1.getString("receiver_name");
				String sub=rs_1.getString("subject");
				String mess=rs_1.getString("message");
				String date=rs_1.getString("re_date");
				date =date.substring(0,10);
				String time=rs_1.getString("time");
				model_1.addRow(new Object[] {sendname,sub,mess,date,time});			
			}
			model_1.fireTableDataChanged();
			conn.close();
			st.close();
			rs_1.close();
		}
        catch(Exception e)
        {
        	JOptionPane.showMessageDialog(null,""+e);
        }
		table_1 = new JTable(model_1);
		table_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table_1.setPreferredScrollableViewportSize(new Dimension(640,435));
        table_1.setFillsViewportHeight(true);
		JScrollPane js_1=new JScrollPane(table_1);
        js_1.setVisible(true);
		
		JButton btnView_1 = new JButton("View");
		btnView_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnView_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Read(ac,"sent",table_1.getSelectedRow());        	
			}
		});
		
		JButton btnRefresh_2 = new JButton("Refresh");
		btnRefresh_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnRefresh_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					conn=DriverManager.getConnection(url,user,auth);				
					st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,time from "+ac+"_sent order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
					rs_1=st.executeQuery();
					model_1.setRowCount(0);
					while(rs_1.next())
					{
						String sendname=rs_1.getString("receiver_name");
						String sub=rs_1.getString("subject");
						String mess=rs_1.getString("message");
						String date=rs_1.getString("re_date");
						date =date.substring(0,10);
						String time=rs_1.getString("time");
						model_1.addRow(new Object[] {sendname,sub,mess,date,time});						
					}
					model_1.fireTableDataChanged();
					conn.close();
					st.close();
					rs_1.close();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null,""+e);
				}
			}
		});
		
		JButton btnDelete_2 = new JButton("Delete");
		btnDelete_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
        			LocalDateTime obj=LocalDateTime.now();
            		Class.forName("oracle.jdbc.driver.OracleDriver");
        			conn=DriverManager.getConnection(url,user,auth);
        			Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        			rs=stm.executeQuery("Select sender_id,sender_name,receiver_name,subject,message,re_date,time,attach,attach_type from "+ac+"_sent order by re_date desc");
            		rs.absolute(table_1.getSelectedRow()+1);
            		st1=conn.prepareStatement("insert into "+ac+"_trash values(?,?,?,?,?,to_date(?,'MM/DD/YYYY HH24:MI:SS'),?,?,?)");
            		st1.setString(1,rs.getString("sender_id"));
            		st1.setString(2,rs.getString("sender_name"));
            		st1.setString(3,rs.getString("receiver_name"));
            		st1.setString(4,rs.getString("subject"));
            		st1.setString(5,rs.getString("message"));
            		st1.setString(6,df.format(obj));
            		st1.setString(7,tf.format(obj));
            		st1.setBlob(8,rs.getBlob("attach"));
            		st1.setString(9,rs.getString("attach_type"));
            		st1.executeQuery();
            		rs.absolute(table_1.getSelectedRow()+1);
            		rs.deleteRow();
            		conn.close();
            		st.close();
            		JOptionPane.showMessageDialog(null,"Delete Successful");
            		st1.close();
            		rs.close();
            	}
            	catch(Exception e)
            	{
            		JOptionPane.showMessageDialog(null,""+e);
            	}		
			}
		});
		btnDelete_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		GroupLayout gl_jp2 = new GroupLayout(jp2);
		gl_jp2.setHorizontalGroup(
			gl_jp2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_jp2.createSequentialGroup()
					.addGroup(gl_jp2.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_jp2.createSequentialGroup()
							.addGap(110)
							.addComponent(btnView_1, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
							.addGap(97)
							.addComponent(btnRefresh_2, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
							.addGap(73)
							.addComponent(btnDelete_2, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_jp2.createSequentialGroup()
							.addContainerGap()
							.addComponent(js_1, GroupLayout.DEFAULT_SIZE, 690, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_jp2.setVerticalGroup(
			gl_jp2.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_jp2.createSequentialGroup()
					.addContainerGap()
					.addComponent(js_1, GroupLayout.PREFERRED_SIZE, 502, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_jp2.createParallelGroup(Alignment.LEADING, false)
						.addComponent(btnDelete_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(gl_jp2.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnRefresh_2, GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
							.addComponent(btnView_1, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)))
					.addGap(3))
		);
		jp2.setLayout(gl_jp2);
		model_2 = new DefaultTableModel(null,header)
		 {
	    	   public boolean isCellEditable(int row, int column)
	    	   {
	    		      return false;//This causes all cells to be not editable
	    	   }
	       };;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection(url,user,auth);
			st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,time from "+ac+"_trash order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs_2=st.executeQuery();
			while(rs_2.next())
			{
				String sendname=rs_2.getString("receiver_name");
				String sub=rs_2.getString("subject");
				String mess=rs_2.getString("message");
				String date=rs_2.getString("re_date");
				date =date.substring(0,10);
				String time=rs_2.getString("time");
				model_2.addRow(new Object[] {sendname,sub,mess,date,time});		
			}
			rs_2.close();
			conn.close();
			st.close();
		}
       catch(Exception e)
       {
       	JOptionPane.showMessageDialog(null,""+e);
       }
		tabbedPane.add("Draft MAil", jp5);
		model_3 = new DefaultTableModel(null,header)
		 {
	    	   public boolean isCellEditable(int row, int column)
	    	   {
	    		      return false;//This causes all cells to be not editable
	    	   }
	       };;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection(url,user,auth);
			st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,time from "+ac+"_draft order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs_3=st.executeQuery();
			while(rs_3.next())
			{
				String sendname=rs_3.getString("receiver_name");
				String sub=rs_3.getString("subject");
				String mess=rs_3.getString("message");
				String date=rs_3.getString("re_date");
				date =date.substring(0,10);
				String time=rs_3.getString("time");
				model_3.addRow(new Object[] {sendname,sub,mess,date,time});
			}
			rs_3.close();
			conn.close();
			st.close();
		}
      catch(Exception e)
      {
      	JOptionPane.showMessageDialog(null,""+e);
      }
		table_3 = new JTable(model_3);
		table_3.setBorder(new CompoundBorder());
		table_3.setFillsViewportHeight(true);
		table_3.setPreferredScrollableViewportSize(new Dimension(640,435));
		table_3.setPreferredSize(new Dimension(640,435));
		JScrollPane js_3=new JScrollPane(table_3);
      js_3.setVisible(true);
		
		JButton btnView_3 = new JButton("View");
		btnView_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnView_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Read(ac,"draft",table_3.getSelectedRow());
			}
		});
		
		JButton btnRefresh_3 = new JButton("Refresh");
		btnRefresh_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnRefresh_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					conn=DriverManager.getConnection(url,user,auth);				
					st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,time from "+ac+"_draft order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
					rs_3=st.executeQuery();
					model_3.setRowCount(0);
					while(rs_3.next())
					{
						String sendname=rs_3.getString("receiver_name");
						String sub=rs_3.getString("subject");
						String mess=rs_3.getString("message");
						String date=rs_3.getString("re_date");
						date =date.substring(0,10);
						String time=rs_3.getString("time");
						model_3.addRow(new Object[] {sendname,sub,mess,date,time});
						
					}
					rs_3.close();
					conn.close();
					st.close();
				}
		      catch(Exception e1)
		      {
		      	JOptionPane.showMessageDialog(null,""+e1);
		      }
				table_3 = new JTable(model_3);
				table_3.setPreferredScrollableViewportSize(new Dimension(645,435));
		      table_3.setFillsViewportHeight(true);
				JScrollPane js_3=new JScrollPane(table_3);
		      js_3.setVisible(true);
				
			}
		});
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
            		Class.forName("oracle.jdbc.driver.OracleDriver");
        			conn=DriverManager.getConnection(url,user,auth);
        			Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        			rs=stm.executeQuery("Select sender_id,sender_name,receiver_name,subject,message,re_date,time,attach,attach_type from "+ac+"_draft order by re_date desc");
            		rs.absolute(table_3.getSelectedRow()+1);
            		rs.deleteRow();
            		JOptionPane.showMessageDialog(null,"Delete Successful");
            		st1.close();
            		rs.close();
            	}
            	catch(Exception e)
            	{
            		JOptionPane.showMessageDialog(null,""+e);
            	}	
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JButton btnNewButton_3 = new JButton("Send");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
        			LocalDateTime obj=LocalDateTime.now();
            		Class.forName("oracle.jdbc.driver.OracleDriver");
        			conn=DriverManager.getConnection(url,user,auth);
        			Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        			rs=stm.executeQuery("Select sender_id,sender_name,receiver_name,subject,message,re_date,time,attach,attach_type from "+ac+"_draft order by re_date desc");
            		rs.absolute(table_3.getSelectedRow()+1);
            		st1=conn.prepareStatement("insert into "+rs.getString("receiver_name")+"_inbox values(?,?,?,?,?,to_date(?,'MM/DD/YYYY HH24:MI:SS'),?,?,?)");
            		st1.setString(1,rs.getString("sender_id"));
            		st1.setString(2,rs.getString("sender_name"));
            		st1.setString(3,rs.getString("receiver_name"));
            		st1.setString(4,rs.getString("subject"));
            		st1.setString(5,rs.getString("message"));
            		st1.setString(6,df.format(obj));
            		st1.setString(7,tf.format(obj));
            		st1.setBlob(8,rs.getBlob("attach"));
            		st1.setString(9,rs.getString("attach_type"));
            		st1.executeQuery();
            		rs.absolute(table_3.getSelectedRow()+1);
            		rs.deleteRow();
            		conn.close();
            		st.close();
            		JOptionPane.showMessageDialog(null,"Sent Successful");
            		st1.close();
            		rs.close();
            	}
            	catch(Exception e1)
            	{
            		JOptionPane.showMessageDialog(null,""+e1);
            	}		
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		GroupLayout gl_jp5 = new GroupLayout(jp5);
		gl_jp5.setHorizontalGroup(
			gl_jp5.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_jp5.createSequentialGroup()
					.addGroup(gl_jp5.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_jp5.createSequentialGroup()
							.addContainerGap()
							.addComponent(js_3, GroupLayout.PREFERRED_SIZE, 690, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_jp5.createSequentialGroup()
							.addGap(74)
							.addComponent(btnNewButton_3, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(55)
							.addComponent(btnView_3, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(63)
							.addComponent(btnRefresh_3, GroupLayout.PREFERRED_SIZE, 103, GroupLayout.PREFERRED_SIZE)
							.addGap(72)
							.addComponent(btnNewButton_2)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_jp5.setVerticalGroup(
			gl_jp5.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_jp5.createSequentialGroup()
					.addContainerGap()
					.addComponent(js_3, GroupLayout.PREFERRED_SIZE, 484, GroupLayout.PREFERRED_SIZE)
					.addGap(15)
					.addGroup(gl_jp5.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton_3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(Alignment.TRAILING, gl_jp5.createParallelGroup(Alignment.LEADING, false)
							.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnRefresh_3, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnView_3, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		jp5.setLayout(gl_jp5);
		jfacc.getContentPane().add(tabbedPane);
		JLabel lblNewLabel = new JLabel("HI "+ac);
		lblNewLabel.setBounds(548, 34, 146, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		JPanel jp4=new JPanel();
		tabbedPane.add("Trash MAils", jp4);
		table_2 = new JTable(model_2);
		table_2.setPreferredScrollableViewportSize(new Dimension(640,435));
		table_2.setFillsViewportHeight(true);
		// table_2.setPreferredSize(new Dimension(640,435));
		JScrollPane js_2_1=new JScrollPane(table_2);
		js_2_1.setBounds(10, 11, 690, 490);
		js_2_1.setVisible(true);
		
		JButton btnView_2 = new JButton("View");
		btnView_2.setBounds(106, 512, 124, 37);
		btnView_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnView_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Read(ac,"trash",table_2.getSelectedRow());
			}
		});
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setBounds(296, 512, 110, 37);
		btnRefresh.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					conn=DriverManager.getConnection(url,user,auth);
					st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,time from "+ac+"_trash order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
					rs_2=st.executeQuery();
					model_2.setRowCount(0);
					while(rs_2.next())
					{
						String sendname=rs_2.getString("receiver_name");
						String sub=rs_2.getString("subject");
						String mess=rs_2.getString("message");
						String date=rs_2.getString("re_date");
						date =date.substring(0,10);
						String time=rs_2.getString("time");
						model_2.addRow(new Object[] {sendname,sub,mess,date,time});	
					}
					rs_2.close();
					conn.close();
					st.close();
				}
		       catch(Exception e1)
		       {
		       	JOptionPane.showMessageDialog(null,""+e1);
		       }
				table_2 = new JTable(model_2);
				table_2.setPreferredScrollableViewportSize(new Dimension(640,435));
		       table_2.setFillsViewportHeight(true);
				JScrollPane js_2=new JScrollPane(table_2);
		       js_2.setVisible(true);
			}
		});
		jp4.setLayout(null);
		jp4.add(js_2_1);
		jp4.add(btnView_2);
		jp4.add(btnRefresh);
		
		JButton btnDelete_1 = new JButton("Delete");
		btnDelete_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
            		Class.forName("oracle.jdbc.driver.OracleDriver");
        			conn=DriverManager.getConnection(url,user,auth);
        			Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        			rs=stm.executeQuery("Select sender_id,sender_name,receiver_name,subject,message,re_date,time,attach,attach_type from "+ac+"_trash order by re_date desc");
            		rs.absolute(table_2.getSelectedRow()+1);
            		rs.deleteRow();
            		JOptionPane.showMessageDialog(null,"Delete successfull");
					}
            		catch(Exception e)
            		{
            			JOptionPane.showMessageDialog(null,""+e);
            		}
			}
		});
		btnDelete_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnDelete_1.setBounds(453, 512, 104, 37);
		jp4.add(btnDelete_1);
		JPanel jp3=new JPanel();
		tabbedPane.add("Compose MAil", jp3);
		textField = new JTextField();
		textField.setBounds(97, 51, 588, 20);
		textField.setColumns(10);
		JLabel lblSendTo = new JLabel("Send To :");
		lblSendTo.setBounds(21, 54, 66, 14);
		textField_1 = new JTextField();
		textField_1.setBounds(97, 104, 588, 20);
		textField_1.setColumns(10);
		JLabel lblSubject = new JLabel("Subject :");
		lblSubject.setBounds(27, 110, 60, 14);
		textArea = new JTextArea();
		textArea.setBounds(97, 161, 599, 310);
		JLabel lblMessage = new JLabel("Message :");
		lblMessage.setBounds(21, 166, 66, 14);
		check1 = new JCheckBox("Attach File?");
		check1.setBounds(97, 478, 102, 23);
		JButton btnSend = new JButton("Send");
		btnSend.setBounds(58, 525, 102, 35);
		btnSend.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			try{	
				LocalDateTime obj=LocalDateTime.now();
				String send=textField.getText();
				String sub=textField_1.getText();
				String message=textArea.getText();
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn=DriverManager.getConnection(url,user,auth);
				st=conn.prepareStatement("insert into "+send+"_inbox values(?,?,?,?,?,to_date(?,'MM/DD/YYYY HH24:MI:SS'),?,?,?)");
				st1=conn.prepareStatement("insert into "+ac+"_sent values(?,?,?,?,?,to_date(?,'MM/DD/YYYY HH24:MI:SS'),?,?,?)");
				st.setString(3,send);
				st.setString(2,name);
				st1.setString(2,name);
				st.setString(1,ac);
				st.setString(4,sub);
				st.setString(5,message);
				st.setString(6,df.format(obj)+" "+tf.format(obj));
				st.setString(7,tf.format(obj));
				st1.setString(3,send);
				st1.setString(1,ac);
				st1.setString(4,sub);
				st1.setString(5,message);
				st1.setString(6,df.format(obj)+" "+tf.format(obj));
				st1.setString(7,tf.format(obj));
					if(check1.isSelected())
					{
						JFileChooser ch=new JFileChooser();
						ch.setCurrentDirectory(new File(System.getProperty("user.home")));
						int r=ch.showOpenDialog(jf);	
						try
						{
							if(r==JFileChooser.APPROVE_OPTION)
							{
							Message temp=new Message("Uploading file please wait");
							File pic=ch.getSelectedFile();
							InputStream x=new FileInputStream(pic);
							st.setBinaryStream(8, x,(int) pic.length());
							st.setString(9, pic.getName());
							st.executeQuery();
							x.close();
							x=new FileInputStream(pic);
							st1.setBinaryStream(8, x,(int) pic.length());
							st1.setString(9, pic.getName());
							st1.executeQuery();
							temp.jfmess.setVisible(false);
							temp.jfmess.dispose();
							x.close();							
							}
						}
						catch(Exception e1)
						{
							JOptionPane.showMessageDialog(null,""+e1);
						}
						
					}
					else
					{
						st.setString(8,null);
						st.setString(9,null);
						st.executeQuery();
						st1.setString(8, null);
						st1.setString(9,null);
						st1.executeQuery();
					}				
					conn.close();
					st.close();
				JOptionPane.showMessageDialog(null,"MAiL sent");
				textField.setText(null);
				textField_1.setText(null);
				textArea.setText(null);
				conn.close();
				st.close();
				st1.close();
				model_1.fireTableDataChanged();
				check1.setSelected(false);
			}
			catch(Exception e1)
			{
				JOptionPane.showMessageDialog(null,""+e1);
			}				
			}
		});
		
		JButton btnNewButton = new JButton("Save as Draft");
		btnNewButton.setBounds(278, 525, 120, 35);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					LocalDateTime obj=LocalDateTime.now();
					String send=textField.getText();
					String sub=textField_1.getText();
					String message=textArea.getText();
					Class.forName("oracle.jdbc.driver.OracleDriver");
					conn=DriverManager.getConnection(url,user,auth);
					st=conn.prepareStatement("insert into "+ac+"_draft values(?,?,?,?,?,to_date(?,'MM/DD/YYYY HH24:MI:SS'),?,?,?)");
					st.setString(3,send);
					st.setString(2,name);
					st.setString(1,ac);
					st.setString(4,sub);
					st.setString(5,message);
					st.setString(6,df.format(obj)+" "+tf.format(obj));
					st.setString(7,tf.format(obj));
					if(check1.isSelected())
					{
						JFileChooser ch=new JFileChooser();
						ch.setCurrentDirectory(new File(System.getProperty("user.home")));
						int r=ch.showOpenDialog(jf);
						
						try
						{
							if(r==JFileChooser.APPROVE_OPTION)
							{
							Message temp=new Message("Uploading file please wait");
							File pic=ch.getSelectedFile();
							InputStream x=new FileInputStream(pic);
							st.setBinaryStream(8, x,(int) pic.length());
							st.setString(9, pic.getName());
							st.executeQuery();
							x.close();
							temp.jfmess.setVisible(false);
							temp.jfmess.dispose();
							}							
						}
						catch(Exception e1)
						{
							JOptionPane.showMessageDialog(null,""+e1);
						}
						
					}
					else
					{
						st.setObject(8,null);
						st.setString(9,null);
						st.executeQuery();					
					}
					JOptionPane.showMessageDialog(null,"Succesfully Saved draft");
					conn.close();
					st.close();
					textField.setText(null);
					textField_1.setText(null);
					textArea.setText(null);
				}
				catch(Exception e2)
				{
					JOptionPane.showMessageDialog(null," "+e2);
				}
			}
		});
		
		JButton btnDiscard = new JButton("Discard ");
		btnDiscard.setBounds(550, 525, 97, 35);
		btnDiscard.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnDiscard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText(null);
				textField_1.setText(null);
				textArea.setText(null);			
			}	
		});
		jfacc.getContentPane().setLayout(null);
		jp3.setLayout(null);
		jp3.add(lblSendTo);
		jp3.add(lblMessage);
		jp3.add(lblSubject);
		jp3.add(textField_1);
		jp3.add(textField);
		jp3.add(check1);
		jp3.add(textArea);
		jp3.add(btnSend);
		jp3.add(btnNewButton);
		jp3.add(btnDiscard);
		jfacc.getContentPane().add(tabbedPane);
		jfacc.getContentPane().add(lblNewLabel);
		JButton btnNewButton_1 = new JButton("Details");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Details(ac);
			}
		});
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnLogOut.setBounds(861, 36, 146, 39);
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			jfacc.setVisible(false);
			jfacc.dispose();	
			}
		});
		jfacc.getContentPane().add(btnLogOut);
		btnNewButton_1.setBounds(280, 36, 115, 39);
		jfacc.getContentPane().add(btnNewButton_1);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Account.class.getResource("/mail/icon.png")));
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(10, 11, 239, 237);
		jfacc.getContentPane().add(label_1);
		
		JLabel label = new JLabel("");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setIcon(new ImageIcon(Account.class.getResource("/mail/back2.jpg")));
		label.setSize(jfacc.getWidth(),jfacc.getHeight());
		//label.setBounds(233, 142, 46, 14);
		jfacc.getContentPane().add(label);
		jfacc.setVisible(true);
	}
}
