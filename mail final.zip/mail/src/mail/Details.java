package mail;
import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Details {
private JFrame jf;
private JLabel lblNewLabel;
private JTextField textField;
private JTextField textField_1;
private JTextField textField_2;
private JTextField textField_3;
private String name,gender,dob,phone,pass;
private JPasswordField passwordField;
	public Details(final String ac) {
		
		jf=new JFrame("Detalis :"+ac);
		jf.setSize(400,670);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setLocationRelativeTo(null);
		JLabel lbl = new JLabel(": Account Details :");
		lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl.setBounds(116, 11, 180, 23);
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(28, 29, 369, 207);
		lblNewLabel.setIcon(new ImageIcon(Details.class.getResource("/mail/icon 2.png")));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		final JButton btnNewButton_2 = new JButton("Save");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText()!=null && textField_1.getText()!=null && textField_2.getText()!=null && textField_3.getText()!=null )
				{	
			try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection conn1=DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-KH3F8LR:1521:orcl","system","ullas");
					PreparedStatement stmt1=conn1.prepareStatement("Update users set username=?,gender=?,phone=?,dob=?,password=? where userid=?");
					stmt1.setString(1,textField.getText());
					stmt1.setString(2,textField_1.getText());
					stmt1.setString(3,textField_3.getText());
					stmt1.setString(4,textField_2.getText());
					stmt1.setString(5,String.valueOf(passwordField.getPassword()));
					stmt1.setString(6,ac);
					stmt1.executeUpdate();
					JOptionPane.showMessageDialog(null,"Update successful");
					conn1.close();
				}
				catch(Exception e)
				{
					new Message(e+"");
				}
				textField.setEditable(false);
				textField_1.setEditable(false);
				textField_2.setEditable(false);
				textField_3.setEditable(false);
				passwordField.setEditable(false);
				btnNewButton_2.setEnabled(false);
				
			}
			
			else
			{
				JOptionPane.showMessageDialog(null,"Fields cannot be empty");
			}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_2.setBounds(263, 572, 89, 34);
		jf.getContentPane().add(btnNewButton_2);
		btnNewButton_2.setEnabled(false);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn1=DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-KH3F8LR:1521:orcl","system","ullas");
			PreparedStatement stmt1=conn1.prepareStatement("Select username,gender,dob,phone,password from users where userid=?",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			stmt1.setString(1,ac);
			ResultSet rs1=stmt1.executeQuery();
			rs1.next();
			name=rs1.getString("username");
			gender=rs1.getString("gender");
			dob=rs1.getString("dob");
			phone=rs1.getString("phone");
			pass=rs1.getString("password");
			conn1.close();
			rs1.close();
		}
		catch(Exception e)
		{
			new Message(e+"");
		}
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(143, 572, 95, 34);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jf.setVisible(false);
				jf.dispose();
			}
		});
		
		JLabel lblName = new JLabel("Name :");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblName.setBounds(28, 286, 69, 14);
		
		JLabel label = new JLabel("Gender :");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(28, 338, 69, 14);
		
		JLabel lblDateOfBirth = new JLabel("Date Of Birth :");
		lblDateOfBirth.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDateOfBirth.setBounds(28, 394, 105, 14);
		
		JLabel lblPhoneNo = new JLabel("Phone No. :");
		lblPhoneNo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPhoneNo.setBounds(26, 440, 77, 14);
		
		textField = new JTextField();
		textField.setBounds(147, 276, 133, 34);
		textField.setColumns(10);
		textField.setEditable(false);
		textField_1 = new JTextField();
		textField_1.setBounds(147, 328, 133, 34);
		textField_1.setColumns(10);
		textField_1.setEditable(false);
		textField_2 = new JTextField();
		textField_2.setBounds(147, 385, 133, 33);
		textField_2.setColumns(10);
		textField_2.setEditable(false);
		textField_3 = new JTextField();
		textField_3.setBounds(147, 431, 133, 33);
		textField_3.setColumns(10);
		textField_3.setEditable(false);
		textField.setText(name);
		textField_1.setText(gender);
		textField_2.setText(dob.substring(0,10));
		textField_3.setText(phone);
		jf.getContentPane().setLayout(null);
		jf.getContentPane().add(lblNewLabel);
		jf.getContentPane().add(lblNewLabel);
		jf.getContentPane().add(lbl);
		jf.getContentPane().add(lblName);
		jf.getContentPane().add(label);
		jf.getContentPane().add(lblDateOfBirth);
		jf.getContentPane().add(lblPhoneNo);
		jf.getContentPane().add(textField_3);
		jf.getContentPane().add(textField_2);
		jf.getContentPane().add(textField_1);
		jf.getContentPane().add(textField);
		jf.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Edit ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setEditable(true);
				textField_1.setEditable(true);
				textField_2.setEditable(true);
				textField_3.setEditable(true);
				passwordField.setEditable(true);
				btnNewButton_2.setEnabled(true);
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.setBounds(28, 572, 89, 34);
		jf.getContentPane().add(btnNewButton_1);
		
		passwordField = new JPasswordField();
		passwordField.setEditable(false);
		passwordField.setText(pass);
		passwordField.setBounds(147, 488, 133, 34);
		jf.getContentPane().add(passwordField);
		
		JLabel lblNewLabel_1 = new JLabel("Password :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(28, 488, 75, 24);
		jf.getContentPane().add(lblNewLabel_1);
		
		
		JLabel label_1 = new JLabel("");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_1.setIcon(new ImageIcon(Details.class.getResource("/mail/back3.png")));
		label_1.setBounds(0, 0, 384, 631);
		jf.getContentPane().add(label_1);
		jf.setVisible(true);
	}
}
