package mail;
import javax.swing.*;
import java.sql.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.awt.Color;
import java.awt.Font;
public class Login {
 JTextField textField;
 JPasswordField passwordField;
 JFrame jf;
 final String url=new String("jdbc:oracle:thin:@DESKTOP-KH3F8LR:1521:orcl");
 final String user=new String("system");
 final String auth=new String("ullas");
 String id,pass;
	Login(){
jf=new JFrame("LOGIN");
jf.getContentPane().setBackground(new Color(192, 192, 192));
jf.getContentPane().setForeground(new Color(0, 0, 0));
jf.setSize(400,700);
jf.setLocationRelativeTo(null);
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
textField = new JTextField();
textField.setBounds(196, 241, 133, 28);
textField.setColumns(10);
passwordField = new JPasswordField();
passwordField.setBounds(196, 328, 133, 28);
final JButton btnNewButton = new JButton("LOGIN");
btnNewButton.setBackground(Color.WHITE);
btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
btnNewButton.setForeground(new Color(0, 0, 0));
btnNewButton.setBounds(151, 427, 96, 38);
btnNewButton.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
	 id=String.valueOf(textField.getText());
	 pass=String.valueOf(passwordField.getPassword());
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection(url,user,auth);
			PreparedStatement st=conn.prepareStatement("Select * from users where userid=?");
			st.setString(1,id);
			ResultSet rs=st.executeQuery();
			rs.next();
			if(rs.getString("password").equals(pass))
			{
				new Account(id,rs.getString("username"));
				jf.setVisible(false);
				jf.dispose();
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Invalid Password");
			}
			conn.close();
			st.close();
			rs.close();
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,"Invalid Userid/Password \n Retry"+e);
		}
		
	}
});

passwordField.addKeyListener(new KeyAdapter() {
	@Override
	public void keyTyped(KeyEvent arg0) {
		if(arg0.getKeyChar()==10)
		{			
			btnNewButton.doClick();
		}
		
	}
});
JButton btnNewButton_1 = new JButton("SIGN UP");
btnNewButton_1.setBackground(Color.WHITE);
btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
btnNewButton_1.setForeground(new Color(0, 0, 0));
btnNewButton_1.setBounds(49, 486, 105, 37);
btnNewButton_1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
		new Sign();
		jf.setVisible(false);
		jf.dispose();
	}
});
JButton btnNewButton_2 = new JButton("EXIT");
btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
btnNewButton_2.setForeground(new Color(0, 0, 0));
btnNewButton_2.setBackground(Color.WHITE);
btnNewButton_2.setBounds(265, 485, 96, 38);
btnNewButton_2.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		jf.dispose();
		System.exit(0);
	}
});
JLabel lblUsername = new JLabel("USER ID :");
lblUsername.setBackground(Color.WHITE);
lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 14));
lblUsername.setBounds(79, 244, 75, 14);
JLabel lblPassword = new JLabel("PASSWORD :");
lblPassword.setBackground(Color.WHITE);
lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 14));
lblPassword.setBounds(79, 331, 96, 14);
jf.getContentPane().setLayout(null);
jf.getContentPane().add(btnNewButton_1);
jf.getContentPane().add(btnNewButton_2);
jf.getContentPane().add(lblPassword);
jf.getContentPane().add(lblUsername);
jf.getContentPane().add(textField);
jf.getContentPane().add(passwordField);
jf.getContentPane().add(btnNewButton);
JLabel label = new JLabel("");
label.setIcon(new ImageIcon(Login.class.getResource("/mail/icon 2.png")));
label.setHorizontalAlignment(SwingConstants.CENTER);
label.setBounds(33, 0, 374, 208);
jf.getContentPane().add(label);
JLabel lblNewLabel = new JLabel("New label");
lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/mail/back.png")));
lblNewLabel.setBounds(-29, 0, 451, 658);
jf.getContentPane().add(lblNewLabel);
jf.setVisible(true);
	}
}
