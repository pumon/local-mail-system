package mail;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class Message {
	JFrame jfmess;
	Message(String mgs)
	{
		 jfmess=new JFrame(mgs);
		 jfmess.setLocationRelativeTo(null);
		jfmess.setSize(300, 300);
		jfmess.setVisible(true);
		jfmess.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jfmess.setVisible(false);
				jfmess.dispose();
			}
		});
		JLabel lblNewLabel = new JLabel(mgs);
		GroupLayout groupLayout = new GroupLayout(jfmess.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addComponent(btnOk, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
							.addGap(96))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
					.addGap(18)
					.addComponent(btnOk)
					.addGap(32))
		);
		jfmess.getContentPane().setLayout(groupLayout);
		
	}
}
