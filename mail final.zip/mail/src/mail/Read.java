package mail;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.sql.*;
import java.util.StringTokenizer;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.awt.Font;
public class Read {
private JFrame jf;
private JTextField textField;
private JTextField textField_1;
private JTextField textField_2;
private JButton btnDownload;
private JLabel lblFile;
private ResultSet rs1,rs2;
private String message,sub,s,to;
final String url=new String("jdbc:oracle:thin:@DESKTOP-KH3F8LR:1521:orcl");
final String user=new String("system");
final String auth=new String("ullas");
	public Read(final String ac,final String tab,final int index) {
		jf=new JFrame("READ");
		jf.setSize(600,600);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setLocationRelativeTo(null);
		JLabel lblSender = new JLabel("From :");
		lblSender.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSender.setBounds(77, 62, 87, 14);
		
		JLabel lblSubject = new JLabel("Subject :");
		lblSubject.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSubject.setBounds(77, 142, 87, 18);
		
		JLabel lblMessage = new JLabel("Message :");
		lblMessage.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMessage.setBounds(77, 204, 100, 20);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setBounds(251, 514, 73, 36);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				jf.dispose();
			}
		});
		
		btnDownload = new JButton("Download");
		btnDownload.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnDownload.setBounds(458, 203, 100, 23);
		btnDownload.setVisible(true);
		btnDownload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection conn=DriverManager.getConnection(url,user,auth);
					PreparedStatement st=conn.prepareStatement("Select attach,attach_type from "+ac+"_"+tab+" order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
					rs2=st.executeQuery();
					rs2.absolute(index+1);
					JFileChooser chooser=new JFileChooser();
					chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
					StringTokenizer ext=new StringTokenizer(rs2.getString("attach_type"),".");
					String extt=ext.nextToken();
					extt=ext.nextToken();
					chooser .addChoosableFileFilter(new FileNameExtensionFilter("Download", extt));
					int r=chooser.showSaveDialog(jf);
					if(r==JFileChooser.APPROVE_OPTION)
					{
							Message obj=new Message("Saving file");
							Blob lob=null;
			        	     rs2.absolute(index+1);
			        	     File file=new File(chooser.getSelectedFile().getAbsolutePath());
			        	     lob=rs2.getBlob("attach");  
			                InputStream inputStream = lob.getBinaryStream();
			                OutputStream outputStream = new FileOutputStream(file);
			                int bytesRead = -1;
			                byte[] buffer = new byte[(int)lob.length()];
			                while ((bytesRead = inputStream.read(buffer)) != -1) {
			                    outputStream.write(buffer, 0, bytesRead);
			                }
			 
			                inputStream.close();
			                outputStream.close();
			         obj.jfmess.setVisible(false);
			         obj.jfmess.dispose();
			         JOptionPane.showMessageDialog(null,"File saved successfully");
			         rs2.close();
			         conn.close();
			         st.close();
			         }
					
					else
					{
						JOptionPane.showMessageDialog(null,"Please Select Directory");
					}
					
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null,""+e);
				}
				
			}
		});
		
		lblFile = new JLabel("File: ");
		lblFile.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblFile.setBounds(276, 207, 185, 14);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection(url,user,auth);
			PreparedStatement st=conn.prepareStatement("Select sender_name,receiver_name,subject,message,re_date,attach_type from "+ac+"_"+tab+" order by re_date desc",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs1=st.executeQuery();
			rs1.absolute(index+1);
			message=rs1.getString("message");
			s=rs1.getString("sender_name");
			to=rs1.getString("receiver_name");
			sub=rs1.getString("subject");
			rs1.getString("attach_type");
			if(rs1.wasNull())
			{
				btnDownload.setVisible(false);
				lblFile.setText("File: No Attachment");
			}
			else{
				lblFile.setText("FILE:"+rs1.getString("attach_type"));
			}
			conn.close();
			st.close();
			rs1.close();
		}
		
		catch(Exception a)
		{
			new Message(""+a);
		}
		JTextArea textArea = new JTextArea(message);
		textArea.setBounds(77, 232, 481, 269);
		textArea.setEditable(false);
		jf.setVisible(true);
		textField = new JTextField(s);
		textField.setBounds(191, 45, 367, 35);
		textField.setColumns(10);
		
		textField.setEditable(false);
		textField_1 = new JTextField(sub);
		textField_1.setBounds(191, 136, 367, 30);
		textField_1.setColumns(10);
		textField_1.setEditable(false);
		
		JLabel lblTo = new JLabel("To :");
		lblTo.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTo.setBounds(77, 94, 55, 20);
		
		textField_2 = new JTextField();
		textField_2.setBounds(191, 91, 367, 35);
		textField_2.setColumns(10);
		textField_2.setEditable(false);
		textField_2.setText(to);
		
		JLabel lblLetter = new JLabel(": Letter :");
		lblLetter.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblLetter.setBounds(251, 11, 87, 23);
		
		JLabel label = new JLabel("");
		label.setBounds(360, 166, 0, 0);
		jf.getContentPane().setLayout(null);
		jf.getContentPane().add(lblMessage);
		jf.getContentPane().add(lblSubject);
		jf.getContentPane().add(lblSender);
		jf.getContentPane().add(lblTo);
		jf.getContentPane().add(textField_2);
		jf.getContentPane().add(textField);
		jf.getContentPane().add(textField_1);
		jf.getContentPane().add(lblFile);
		jf.getContentPane().add(btnDownload);
		jf.getContentPane().add(textArea);
		jf.getContentPane().add(btnBack);
		jf.getContentPane().add(lblLetter);
		jf.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Read.class.getResource("/mail/back4.jpg")));
		label_1.setBounds(0, 0, 584, 561);
		jf.getContentPane().add(label_1);
	}
}
