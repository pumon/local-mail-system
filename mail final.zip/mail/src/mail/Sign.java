package mail;

import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
public class Sign {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
   JFrame jfsign;
   final String url=new String("jdbc:oracle:thin:@DESKTOP-KH3F8LR:1521:orcl");
   final String user=new String("system");
   final String auth=new String("ullas");
   private JTextField textField_2;
   private JPasswordField passwordField;
   private JPasswordField passwordField_1;
   @SuppressWarnings("rawtypes")
private JComboBox comboBox;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	Sign()
	{
		jfsign=new JFrame();
		jfsign.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jfsign.setSize(450,600);
		jfsign.setLocationRelativeTo(null);
		JLabel lblSignUp = new JLabel(": SIGN UP :");
		lblSignUp.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblSignUp.setBounds(157, 11, 135, 36);
		
		JLabel lblFisrtName = new JLabel("First Name:*");
		lblFisrtName.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblFisrtName.setBounds(60, 74, 138, 14);
		
		JLabel lblLastName = new JLabel("Last Name:*");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblLastName.setBounds(60, 122, 138, 14);
		
		textField = new JTextField();
		textField.setBounds(247, 68, 89, 20);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(247, 116, 89, 20);
		textField_1.setColumns(10);
		
		JLabel lblDateOfBirth = new JLabel("Date Of Birth:*");
		lblDateOfBirth.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDateOfBirth.setBounds(60, 197, 138, 14);
		
		textField_3 = new JTextField();
		textField_3.setBounds(247, 239, 89, 20);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Phone No.:*");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(60, 245, 138, 14);
		
		textField_4 = new JTextField();
		textField_4.setBounds(247, 293, 89, 20);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("User ID:*");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(60, 299, 138, 14);
		
		JLabel lblNewLabel_2 = new JLabel("Password:*");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(60, 343, 138, 14);
		
		JLabel lblNewLabel_3 = new JLabel("Retype Password:*");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(60, 397, 138, 14);
		
		JButton btnNewButton = new JButton("Sign up");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(92, 497, 96, 33);
		
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(223, 497, 80, 33);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Login();
				jfsign.setVisible(false);
				jfsign.dispose();
				
			}
		});
		
		JLabel lblGender = new JLabel("Gender:*");
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblGender.setBounds(60, 156, 138, 14);
		String [] c={"Male","Female","Others"};
		
		comboBox = new JComboBox(c);
		comboBox.setBounds(247, 154, 89, 20);
		textField_2 = new JTextField();
	
		textField_2.setBounds(250, 191, 86, 20);
		textField_2.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(247, 337, 89, 20);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(247, 391, 89, 20);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String uid=textField_4.getText(),fn=textField.getText(),ln=textField_1.getText(),pass1=String.valueOf(passwordField.getPassword()),dob=textField_2.getText();
				long pho=Long.parseLong(textField_3.getText());
				String gen=String.valueOf(comboBox.getItemAt(comboBox.getSelectedIndex()));
				String pass2=String.valueOf(passwordField_1.getPassword());
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection conn=DriverManager.getConnection(url,"system",auth);
					PreparedStatement ps=conn.prepareStatement("insert into users values(?,?,?,?,?,?,?,?)");
					ps.setString(1,uid);
					ps.setString(2,fn);
					ps.setString(3,ln);
					ps.setString(4,fn+" "+ln);
					ps.setString(5,pass1);
					ps.setString(6,gen);
					ps.setString(7,dob);
					ps.setLong(8,pho);
					if(pass1.equals(pass2))
					{
						ps.executeQuery();
					Statement st=conn.createStatement();
					st=conn.createStatement();
					st.executeQuery("create table "+uid+"_inbox (sender_id varchar(20),sender_name varchar(30),receiver_name varchar(30),subject varchar(30),message varchar(500),re_date date,time varchar(10),attach blob,attach_type varchar(70),foreign key(sender_id) references users(userid))");
					st.executeQuery("create table "+uid+"_sent (sender_id varchar(20),sender_name varchar(30),receiver_name varchar(30),subject varchar(30),message varchar(500),re_date date,time varchar(10),attach blob,attach_type varchar(70),foreign key(sender_id) references users(userid))");
					st.executeQuery("create table "+uid+"_trash (sender_id varchar(20),sender_name varchar(30),receiver_name varchar(30),subject varchar(30),message varchar(500),re_date date,time varchar(10),attach blob,attach_type varchar(70),foreign key(sender_id) references users(userid))");
					st.executeQuery("create table "+uid+"_draft (sender_id varchar(20),sender_name varchar(30),receiver_name varchar(30),subject varchar(30),message varchar(500),re_date date,time varchar(10),attach blob,attach_type varchar(70),foreign key(sender_id) references users(userid))");
					st.executeQuery("commit");
					JOptionPane.showMessageDialog(null,"Successfully created user "+uid);
					conn.close();
					ps.close();
					st.close();
					jfsign.setVisible(false);
					jfsign.dispose();
					new Login();
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Passwords entered doesnt match");
					}
				}
				catch(ClassNotFoundException c)
				{
					JOptionPane.showMessageDialog(null,"Error Check Driver");
				}
				catch(SQLException e)
				{
					
					JOptionPane.showMessageDialog(null,"Error "+e);
				}
			}
		});
		jfsign.getContentPane().setLayout(null);
		jfsign.getContentPane().add(lblNewLabel_1);
		jfsign.getContentPane().add(lblNewLabel);
		jfsign.getContentPane().add(lblLastName);
		jfsign.getContentPane().add(lblFisrtName);
		jfsign.getContentPane().add(lblGender);
		jfsign.getContentPane().add(lblDateOfBirth);
		jfsign.getContentPane().add(lblNewLabel_2);
		jfsign.getContentPane().add(lblNewLabel_3);
		jfsign.getContentPane().add(textField_2);
		jfsign.getContentPane().add(passwordField_1);
		jfsign.getContentPane().add(passwordField);
		jfsign.getContentPane().add(textField_1);
		jfsign.getContentPane().add(textField);
		jfsign.getContentPane().add(textField_3);
		jfsign.getContentPane().add(textField_4);
		jfsign.getContentPane().add(btnNewButton_1);
		jfsign.getContentPane().add(comboBox);
		jfsign.getContentPane().add(btnNewButton);
		
		JLabel lblExjan = new JLabel("Ex:01-Jan-2001");
		lblExjan.setBounds(337, 197, 97, 15);
		jfsign.getContentPane().add(lblExjan);
		jfsign.getContentPane().add(lblSignUp);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Sign.class.getResource("/mail/back.png")));
		label.setBounds(0, 0, 434, 561);
		jfsign.getContentPane().add(label);
		jfsign.setVisible(true);
	}
}
